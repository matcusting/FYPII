@echo off
setlocal
cd /d "%~dp0"

if not exist "runtime\node.exe" (
  echo Missing runtime\node.exe. Please extract the entire ZIP first.
  pause
  exit /b 1
)

start "UTS Housing Preview Server" "%~dp0runtime\server.cmd"
timeout /t 3 /nobreak >nul

set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%LocalAppData%\Google\Chrome\Application\chrome.exe"

if exist "%CHROME%" (
  start "" "%CHROME%" "http://127.0.0.1:4173/"
) else (
  start "" "http://127.0.0.1:4173/"
)

echo If Chrome did not open, type http://127.0.0.1:4173/ into Chrome.
echo Keep the separate Preview Server window open while browsing.
pause
