@echo off
cd /d "%~dp0.."
echo UTS Housing Preview Server
echo Keep this window open while browsing the website.
echo.
"%~dp0node.exe" "%~dp0..\preview\demo-server.mjs"
echo.
echo The preview server has stopped. Press a key to close this window.
pause >nul
