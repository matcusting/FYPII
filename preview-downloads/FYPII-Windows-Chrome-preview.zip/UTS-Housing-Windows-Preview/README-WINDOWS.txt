UTS Housing & Roommate Finder — Windows Chrome 预览

1. 下载 ZIP 后，在 Windows 文件管理器中右键压缩包，选择“全部解压”。
2. 进入解压后的 UTS-Housing-Windows-Preview 文件夹。
3. 双击 START-WEBSITE.cmd，并保持“UTS Housing Preview Server”窗口开着。
4. 如 Chrome 没有自动打开，在同一台电脑输入 http://127.0.0.1:4173/ 。
5. 结束预览时关闭服务窗口。

已附带 Windows x64 Node.js v20.19.5；不需要另外安装 Node.js 或运行 npm。请先全部解压，不要直接在 ZIP 内运行启动文件。Node.js 许可证见 runtime\NODE-LICENSE.txt。

演示账号（密码均为 Demo12345!）：
学生 student@demo.local
待认证学生 verification-demo@student.uts.edu.my
房东 landlord@demo.local
待认证房东 landlord-applicant@demo.local
管理员 admin@demo.local

也可模拟注册学生（使用未用过的 demo-...@student.uts.edu.my）或房东（使用未用过的 @demo.local 邮箱）。注册、补发验证链接和密码重设会在页面显示本机模拟链接，不会发送真实邮件。学生可提交虚构学生证和录取通知书；房东可提交虚构身份与逐房源出租授权材料。管理员在相应审核队列批准或拒绝，也可处理账户删除申请、查看审计日志，以及撤销房东认证。审核批准学生时须人工确认虚构学号和学校邮箱前缀一致。

所有数据仅存在于演示服务内存，重启即恢复初始状态。上传文件内容会立即丢弃，管理员看到的是通用占位图；请勿提交真实证件、租约或个人资料。此包不连接正式 API 或 PostgreSQL，也不能代替真实邮件及证件保管服务。

网站默认英文，可切换马来文或简体中文。Google Maps 已移除；房东填写完整房屋地址，并可选择是否向已登录学生公开。127.0.0.1 是这台电脑自己的地址，只有服务窗口开着时才可以访问。
