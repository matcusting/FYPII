UTS Housing & Roommate Finder — Windows Chrome 预览

1. 下载 ZIP 后，在 Windows 文件管理器中右键压缩包，选择“全部解压”。
2. 进入解压后的 UTS-Housing-Windows-Preview 文件夹。
3. 双击 START-WEBSITE.cmd。会出现一个“UTS Housing Preview Server”命令窗口；请保持它开着。
4. 网站会尝试自动在 Chrome 打开。如果没有，在 Chrome 地址栏输入 http://127.0.0.1:4173/ 。
5. 结束预览时关闭“UTS Housing Preview Server”窗口。

这个包已经附带 Windows x64 的 Node.js 运行程序，不需要另外安装 Node.js，也不需要运行 npm。一定要先“全部解压”；直接在压缩包内双击启动文件不能正常运行。

演示账号（密码均为 Demo12345!）：
学生 student@demo.local
房东 landlord@demo.local
管理员 admin@demo.local

所有账号和房源都是虚构演示数据，重启预览服务后恢复初始状态。真实后端、邮件及付款服务没有接入；请勿输入真实个人资料。127.0.0.1 是你自己的电脑地址，只有在启动服务并保持服务窗口打开时才可以访问。

内附 Node.js v20.19.5 win-x64，来源于 nodejs.org，发行包 SHA-256 已对照官方 SHASUMS256.txt 验证。许可证见 runtime\NODE-LICENSE.txt。

此版本已移除 Google Maps。房东填写完整房屋地址，可自行选择是否在审核通过后向已登录学生公开。设施增加衣柜、冰箱、热水器、独立卫浴、厨房使用、书桌、监控和阳台。房东个人资料为姓名、只读账号邮箱及联系电话。
